# HomeSchool — Progress section

This ZIP exports the current Progress implementation from iOS-Homeschooling-App.
The Swift source files are unchanged copies of the working project.

## Included

- Progress/: ProgressDashboardView.swift (Day / Week / Month learning-time chart, day selection,
  totals, child switcher and completion updates) and SubjectLearningCard.swift
  (expandable subject cards and activity checklists).
- SupportingSource/: progress/weekly-plan/child/curriculum models and shared colours,
  typography and font scaling. WeekActivity and DayLearningSummary are defined in WeeklyPlan.swift.
- IntegrationReferences/: existing shared app state, child switching, weekly-plan editing,
  daily wrap-up UI and reusable components, supplied as integration context.
- SHA256SUMS.txt: checksums for every included Swift source file.

## Using it

The Progress entry point is ProgressDashboardView. In the original app it is opened with:

```swift
NavigationStack {
    ProgressDashboardView()
}
.environment(appState) // An existing AppState instance, owned by the app.
```

Use the original Homeschool Xcode project for a complete runnable app. This is a source
bundle, not a standalone Xcode project or Swift package. The reference files depend on
other host-app features/services (for example ChildSetupSteps, account state, reminders
and the main tab overlay), which are not all included here.

When merging into the existing project, replace/update the two Progress files and reuse
its shared types. Do not add duplicate copies of AppState, Child, Theme or the other
shared definitions to the same target. For a different app, adapt the AppState,
child-setup and weekly-plan navigation hooks to that app's own data layer.

No user data, saved learning logs, credentials, Git history, build outputs or Xcode
personal settings are included. SF Symbols provide the Progress screen's icons;
there are no separate chart image assets required.

## Current source

See EXPORT-SOURCE.txt for the source version. The Progress range calculations live in
LearningProgress.swift. Theme+Gather.swift supplies the shared native glass modifier;
reuse the existing host app styles and Gather types when integrating this source bundle.
For a complete runnable project, use the repository root or HomeSchool-App.zip.
