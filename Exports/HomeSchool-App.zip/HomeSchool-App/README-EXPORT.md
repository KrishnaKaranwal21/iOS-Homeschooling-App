# HomeSchool — Full app project

This archive is a snapshot of the current app workspace. It includes the Swift source,
asset catalog, Xcode project/workspace metadata, scripts, tests and design notes.
Files are copied as they exist in the workspace, including current project configuration.

The Progress screen includes the native Day / Week / Month picker and selectable purple bars.
See EXPORT-SOURCE.txt for the source version.

## Open and run

1. Extract the ZIP.
2. Open Homeschool.xcodeproj in Xcode.
3. Select the Homeschool scheme and an iPhone simulator.
4. Build and run.

Use an Xcode installation that supports the APIs and SDK used by the project. To run on
a physical device, select your own development team under Signing & Capabilities and
adjust the bundle identifier if needed. No signing credentials or provisioning profiles
are included.

## Contents

- Homeschool/App/: entry point, shared app state and tab navigation.
- Homeschool/Features/: all app screens, including Home, Progress, Gather, Community,
  Chats, child setup and login.
- Homeschool/Core/: models, services, shared styles and the native SwiftUI mascot.
- Homeschool/Assets.xcassets/: bundled artwork and other assets.
- Homeschool.xcodeproj/: Xcode project and shared workspace metadata.
- Scripts/ and Tests/: the Gather, booking/QR and Progress range checks.
- DesignNotes/: existing implementation/design notes.
- SHA256SUMS.txt: checksums for the archived files.

## Included checks

From the extracted HomeSchool-App folder on macOS with Xcode command-line tools:

```sh
bash Scripts/check-gather.sh
bash Scripts/check-booking-tickets.sh
```

## Archive boundaries

The ZIP excludes Git history, earlier export ZIPs, build caches, personal Xcode interface
settings, operating-system metadata, credentials and provisioning files. Runtime user
data stored on a device or simulator is not part of the project and is not included.
Local/mock services keep their current behaviour; packaging the app does not add live
backend services or an organizer check-in validation service.
