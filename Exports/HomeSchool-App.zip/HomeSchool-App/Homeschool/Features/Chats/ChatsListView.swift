import SwiftUI
import LocalAuthentication

/// All conversations: search, filter chips and a swipeable list.
struct ChatsListView: View {
    @Environment(AppState.self) private var state
    @Environment(\.openTab) private var openTab

    @State private var query = ""
    @State private var showLabelEditor = false
    @State private var editingLabel: ChatLabel?
    @State private var broadcastLabel: ChatLabel?
    @State private var labelsThread: ThreadRef?
    @State private var openID: ChatThread.ID?
    @State private var showNewChat = false
    @State private var deleteTarget: ChatThread.ID?
    @State private var isConfirmingDelete = false
    @State private var manageLabelID: String?
    @State private var showReorder = false
    @State private var showLocked = false

    private let accent = Color.adaptive(0xD9D2FF, 0x3B3059)
    private let unreadTime = Color.adaptive(0x5B6B2F, 0xC0D788)

    private var selectedLabel: ChatLabel { state.chats.selectedLabel }

    private var threads: [ChatThread] {
        state.chats.threads(for: selectedLabel).filter { thread in
            query.isEmpty
                || thread.title.localizedCaseInsensitiveContains(query)
                || thread.messages.contains { $0.text.localizedCaseInsensitiveContains(query) }
        }
    }

    // MARK: Body

    var body: some View {
        VStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 14) {
                header
                searchField
                chips
            }
            .padding(.horizontal, 18)
            .padding(.top, 6)
            .padding(.bottom, 8)

            labelStrip
            lockedRow

            if threads.isEmpty {
                emptyState
            } else {
                list
            }
        }
        .background(Theme.background)
        .toolbar(.hidden, for: .navigationBar)
        .navigationDestination(item: $openID) { id in
            ChatDetailView(threadID: id)
        }
        .navigationDestination(item: $manageLabelID) { ManageListView(labelID: $0) }
        .overlay(alignment: .bottom) {
            if let toast = state.chats.toast {
                ChatToastView(toast: toast) {
                    state.chats.toast = nil
                    showReorder = true
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 12)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.snappy, value: state.chats.toast)
        .onAppear {
            openPendingChat()
            state.chats.purgeExpired()
        }
        .onChange(of: state.chats.pendingOpenID) { openPendingChat() }
        .sheet(isPresented: $showNewChat) {
            NewChatSheet { id in
                showNewChat = false
                // Wait for the sheet to close before opening the chat.
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { openID = id }
            }
        }
        .sheet(isPresented: $showLabelEditor) { LabelEditorSheet(editing: nil) }
        .sheet(isPresented: $showReorder) { ReorderListsSheet() }
        .sheet(isPresented: $showLocked) {
            LockedChatsView { id in
                showLocked = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { openID = id }
            }
        }
        .sheet(item: $editingLabel) { label in LabelEditorSheet(editing: label) }
        .sheet(item: $broadcastLabel) { label in BroadcastSheet(label: label) }
        .sheet(item: $labelsThread) { ref in ThreadLabelsSheet(threadID: ref.id) }
        .confirmationDialog("Delete this chat?",
                            isPresented: $isConfirmingDelete,
                            titleVisibility: .visible,
                            presenting: deleteTarget) { id in
            Button("Delete chat", role: .destructive) {
                state.chats.delete(id)
                deleteTarget = nil
            }
            Button("Cancel", role: .cancel) { deleteTarget = nil }
        } message: { _ in
            Text("The messages will be removed from this device.")
        }
    }

    /// Opens a chat that another screen asked for, such as "Message host".
    private func openPendingChat() {
        guard let id = state.chats.pendingOpenID else { return }
        state.chats.pendingOpenID = nil
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { openID = id }
    }

    // MARK: Header

    private var header: some View {
        HStack {
            Text("Chats")
                .pageTitle()
            Spacer()
            Button { showNewChat = true } label: {
                Text("New chat")
                    .scaledFont(15, weight: .semibold, maxScale: 1.2)
                    .foregroundStyle(Theme.ink)
                    .padding(.horizontal, 18)
                    .frame(height: 40)
                    .background(Capsule().fill(accent))
            }
            .buttonStyle(.plain)
        }
    }

    private var searchField: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(Theme.secondary)
            TextField("Search chats", text: $query)
                .scaledFont(16, maxScale: 1.3)
                .foregroundStyle(Theme.ink)
                .submitLabel(.search)
            if !query.isEmpty {
                Button { query = "" } label: {
                    Image(systemName: "xmark.circle.fill").foregroundStyle(Theme.dotInactive)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Clear search")
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 46)
        .background(Capsule().fill(Theme.field))
    }

    /// A horizontal bar of filters. Tap to filter, long-press to edit, move, remove or send to everyone under it.
    private var chips: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                ForEach(state.chats.labels) { label in
                    chip(label)
                }

                Button { showLabelEditor = true } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundStyle(Theme.secondary)
                        .frame(width: 46, height: 36)
                        .background(Capsule().fill(Theme.field))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Add a list")
            }
            .padding(.horizontal, 18)
        }
        .scrollIndicators(.hidden)
        .padding(.horizontal, -18)
    }

    private func chip(_ label: ChatLabel) -> some View {
        let selected = state.chats.selectedLabelID == label.id
        let canBroadcast = !label.isBuiltIn || label.id == ChatLabel.favourites.id

        return Button { state.chats.select(label.id) } label: {
            HStack(spacing: 6) {
                if !label.isBuiltIn {
                    Circle().fill(label.color).frame(width: 10, height: 10)
                        .overlay(Circle().stroke(Theme.ink.opacity(0.12), lineWidth: 0.5))
                }
                if label.id == ChatLabel.favourites.id {
                    Image(systemName: "star.fill").font(.system(size: 11))
                }
                Text(label.name)
                    .scaledFont(15, weight: selected ? .semibold : .regular, maxScale: 1.2)
                    .lineLimit(1)
            }
            .foregroundStyle(selected ? Theme.ink : Theme.secondary)
            .padding(.horizontal, 16)
            .frame(height: 36)
            .background(Capsule().fill(selected ? accent : Theme.field))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
        .contextMenu {
            if label.id != ChatLabel.allID {
                Button { state.chats.setMuted(!state.chats.isMuted(label), for: label) } label: {
                    Label(state.chats.isMuted(label) ? "Unmute" : "Mute",
                          systemImage: state.chats.isMuted(label) ? "bell" : "bell.slash")
                }
            }
            if canManage(label) {
                Button { manageLabelID = label.id } label: { Label("Edit", systemImage: "pencil") }
            }
            if canBroadcast {
                Button { broadcastLabel = label } label: {
                    Label("Send to everyone here", systemImage: "paperplane")
                }
            }
            Divider()
            Button { showReorder = true } label: {
                Label("Reorder lists", systemImage: "line.3.horizontal")
            }
        }
    }

    /// Lists whose members can be edited: the ones made by the parent, and Favourites.
    private func canManage(_ label: ChatLabel) -> Bool {
        !label.isBuiltIn || label.id == ChatLabel.favourites.id
    }

    /// Shown above the list while a custom label is selected.
    @ViewBuilder private var labelStrip: some View {
        if !selectedLabel.isBuiltIn && !threads.isEmpty {
            HStack(spacing: 10) {
                Text("\(threads.count) \(threads.count == 1 ? "chat" : "chats") in \(selectedLabel.name)")
                    .scaledFont(14, weight: .medium, maxScale: 1.2)
                    .foregroundStyle(Theme.secondary)
                Spacer()
                Button { broadcastLabel = selectedLabel } label: {
                    Label("Send to all", systemImage: "paperplane.fill")
                        .scaledFont(13, weight: .semibold, maxScale: 1.15)
                        .foregroundStyle(Theme.ink)
                        .padding(.horizontal, 12)
                        .frame(height: 30)
                        .background(Capsule().fill(accent))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 6)
        }
    }

    /// "Manage Tp": opens the list's page to add or remove chats and mute it.
    @ViewBuilder private var manageButton: some View {
        if canManage(selectedLabel) {
            Button { manageLabelID = selectedLabel.id } label: {
                Text("Manage \(selectedLabel.name)")
                    .scaledFont(16, weight: .semibold, maxScale: 1.3)
                    .foregroundStyle(Theme.tabSelected)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .contentShape(.rect)
            }
            .buttonStyle(.plain)
        }
    }

    /// Chats locked with "Chat lock" are kept out of the list. They open after unlocking the phone.
    @ViewBuilder private var lockedRow: some View {
        let locked = state.chats.lockedThreads
        if selectedLabel.id == ChatLabel.allID, !locked.isEmpty, query.isEmpty {
            Button {
                Task { if await ChatAuth.unlock(reason: "Open your locked chats") { showLocked = true } }
            } label: {
                HStack(spacing: 14) {
                    Image(systemName: "lock.fill")
                        .foregroundStyle(Theme.ink)
                        .frame(width: 48, height: 48)
                        .background(Circle().fill(Theme.lavender))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Locked chats")
                            .scaledFont(17, weight: .semibold, maxScale: 1.25)
                            .foregroundStyle(Theme.ink)
                        Text(locked.count == 1 ? "1 chat" : "\(locked.count) chats")
                            .scaledFont(14, maxScale: 1.25)
                            .foregroundStyle(Theme.secondary)
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(Theme.dotInactive)
                }
                .padding(.horizontal, 18)
                .frame(minHeight: 64)
                .contentShape(.rect)
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: List

    private var list: some View {
        List {
            ForEach(threads) { thread in
                row(thread)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets(top: 0, leading: 18, bottom: 0, trailing: 18))
                    .listRowSeparatorTint(Theme.ink.opacity(0.07))
                    .alignmentGuide(.listRowSeparatorLeading) { _ in 74 }
                    .swipeActions(edge: .leading, allowsFullSwipe: true) {
                        if thread.hasUnread {
                            Button { state.chats.markRead(thread.id) } label: {
                                Label("Read", systemImage: "envelope.open")
                            }
                            .tint(Theme.tabSelected)
                        } else {
                            Button { state.chats.markUnread(thread.id) } label: {
                                Label("Unread", systemImage: "envelope.badge")
                            }
                            .tint(Theme.tabSelected)
                        }
                        Button { state.chats.togglePin(thread.id) } label: {
                            Label(thread.isPinned ? "Unpin" : "Pin", systemImage: thread.isPinned ? "pin.slash" : "pin")
                        }
                        .tint(Color.adaptive(0xB5AED0, 0x81798F))
                    }
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) { deleteTarget = thread.id; isConfirmingDelete = true } label: {
                            Label("Delete", systemImage: "trash")
                        }
                        Button { state.chats.toggleMute(thread.id) } label: {
                            Label(thread.isMuted ? "Unmute" : "Mute",
                                  systemImage: thread.isMuted ? "bell" : "bell.slash")
                        }
                        .tint(Color.adaptive(0x8E8E93, 0xA4A3AA))
                    }
                    .contextMenu {
                        Button { labelsThread = ThreadRef(id: thread.id) } label: {
                            Label("Lists…", systemImage: "tag")
                        }
                        Button { state.chats.toggleFavourite(thread.id) } label: {
                            Label(thread.isFavourite ? "Remove from favourites" : "Add to favourites",
                                  systemImage: thread.isFavourite ? "star.slash" : "star")
                        }
                        Button { state.chats.togglePin(thread.id) } label: {
                            Label(thread.isPinned ? "Unpin chat" : "Pin chat", systemImage: "pin")
                        }
                        Button { state.chats.toggleMute(thread.id) } label: {
                            Label(thread.isMuted ? "Unmute" : "Mute", systemImage: "bell.slash")
                        }
                        Button { state.chats.markUnread(thread.id) } label: {
                            Label("Mark as unread", systemImage: "envelope.badge")
                        }
                        Button(role: .destructive) { deleteTarget = thread.id; isConfirmingDelete = true } label: {
                            Label("Delete chat", systemImage: "trash")
                        }
                    }
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .scrollDismissesKeyboard(.immediately)
        .safeAreaInset(edge: .bottom, spacing: 0) { manageButton }
    }

    private func row(_ thread: ChatThread) -> some View {
        Button {
            openID = thread.id
        } label: {
            HStack(spacing: 14) {
                ChatAvatar(thread: thread, size: 56)

                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 6) {
                        Text(thread.title)
                            .scaledFont(17, weight: thread.hasUnread ? .semibold : .regular, maxScale: 1.2)
                            .foregroundStyle(Theme.ink)
                            .lineLimit(1)
                        if thread.isFavourite {
                            Image(systemName: "star.fill")
                                .font(.system(size: 11))
                                .foregroundStyle(Theme.tabIconInactive)
                        }
                        ForEach(labelColors(for: thread), id: \.self) { color in
                            Circle().fill(color).frame(width: 9, height: 9)
                                .overlay(Circle().stroke(Theme.ink.opacity(0.12), lineWidth: 0.5))
                        }
                    }
                    HStack(spacing: 5) {
                        if let last = thread.messages.last, last.isMine {
                            ReadTicks(status: last.status)
                        }
                        Text(thread.preview)
                            .scaledFont(15, maxScale: 1.2)
                            .foregroundStyle(Theme.secondary)
                            .lineLimit(1)
                    }
                }

                Spacer(minLength: 6)

                VStack(alignment: .trailing, spacing: 6) {
                    Text(ChatFormat.listTime(thread.lastDate))
                        .scaledFont(13, maxScale: 1.2)
                        .foregroundStyle(thread.hasUnread && !thread.isMuted ? unreadTime : Theme.secondary)
                    HStack(spacing: 6) {
                        if thread.isPinned {
                            Image(systemName: "pin.fill")
                                .font(.system(size: 12))
                                .foregroundStyle(Theme.secondary)
                        }
                        if thread.isMuted {
                            Image(systemName: "bell.slash")
                                .font(.system(size: 14))
                                .foregroundStyle(Theme.secondary)
                        }
                        if thread.hasUnread {
                            unreadBadge(thread)
                        }
                    }
                    .frame(height: 24)
                }
            }
            .padding(.vertical, 10)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityElement(children: .combine)
        .accessibilityHint("Opens the conversation")
    }

    private func labelColors(for thread: ChatThread) -> [Color] {
        state.chats.customLabels
            .filter { thread.labelIDs.contains($0.id) }
            .prefix(3)
            .map(\.color)
    }

    @ViewBuilder
    private func unreadBadge(_ thread: ChatThread) -> some View {
        if thread.unreadCount > 0 {
            Text("\(thread.unreadCount)")
                .scaledFont(13, weight: .semibold, maxScale: 1.1)
                .foregroundStyle(Theme.ink)
                .frame(minWidth: 24, minHeight: 24)
                .padding(.horizontal, thread.unreadCount > 9 ? 4 : 0)
                .background(Capsule().fill(thread.isMuted ? Theme.dotInactive : accent))
        } else {
            Circle().fill(accent).frame(width: 14, height: 14)
        }
    }

    @ViewBuilder private var emptyState: some View {
        if state.chats.threads.isEmpty {
            welcomeCallout
        } else {
            VStack(spacing: 10) {
                Spacer()
                Image(systemName: query.isEmpty ? "tray" : "magnifyingglass")
                    .font(.system(size: 40))
                    .foregroundStyle(Theme.tabIconInactive)
                Text(query.isEmpty ? "Nothing here yet" : "No results for “\(query)”")
                    .sectionTitle()
                Text(query.isEmpty
                     ? (selectedLabel.isBuiltIn
                        ? "Chats that match this filter will show up here."
                        : "Tap Manage \(selectedLabel.name) below to add people or groups.")
                     : "Try a name or a word from a message.")
                    .pageSubtitle()
                    .multilineTextAlignment(.center)
                Spacer()
                Spacer()
            }
            .padding(.horizontal, 32)
            .frame(maxWidth: .infinity)
            .safeAreaInset(edge: .bottom, spacing: 0) { manageButton }
        }
    }

    /// Shown when there are no conversations at all.
    private var welcomeCallout: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HomeMascotView()
                    .frame(width: 120)
                    .accessibilityHidden(true)

                Text("Your conversations start here")
                    .sectionTitle()

                Text("Connect with parents studying the same NIOS level or join a local gathering to start a conversation.")
                    .scaledFont(16, maxScale: 1.3)
                    .foregroundStyle(Theme.secondary)
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 10) {
                    Button { showNewChat = true } label: {
                        Text("Find parents")
                            .scaledFont(15, weight: .semibold, maxScale: 1.2)
                            .foregroundStyle(Color.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 44)
                            .background(Capsule().fill(Theme.buttonFill))
                    }
                    .buttonStyle(.plain)

                    Button { openTab(.gather) } label: {
                        Text("Join a gathering")
                            .scaledFont(15, weight: .semibold, maxScale: 1.2)
                            .foregroundStyle(Theme.ink)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                            .frame(maxWidth: .infinity)
                            .frame(height: 44)
                            .background(Capsule().fill(Theme.surface))
                    }
                    .buttonStyle(.plain)
                }
                .padding(.top, 4)
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.adaptive(0xE6E1FF, 0x30283F), in: .rect(cornerRadius: 28))
            .padding(.horizontal, 18)
            .padding(.top, 12)
        }
    }
}

// MARK: - Shared pieces

struct ChatAvatar: View {
    let thread: ChatThread
    var size: CGFloat = 56

    var body: some View {
        Text(thread.initials)
            .font(.system(size: size * 0.34, weight: .bold))
            .foregroundStyle(Theme.ink)
            .frame(width: size, height: size)
            .background(Circle().fill(thread.avatarColor))
            .accessibilityHidden(true)
    }
}

/// One tick when sent, two when delivered, two in the accent colour once read.
struct ReadTicks: View {
    let status: MessageStatus

    var body: some View {
        HStack(spacing: -6) {
            Image(systemName: "checkmark")
            if status != .sent { Image(systemName: "checkmark") }
        }
        .font(.system(size: 11, weight: .bold))
        .foregroundStyle(status == .read ? Theme.tabSelected : Theme.secondary)
        .accessibilityLabel(status == .sent ? "Sent" : (status == .delivered ? "Delivered" : "Read"))
    }
}


// MARK: - Locked chats

enum ChatAuth {
    /// Asks for Face ID, Touch ID or the passcode. A phone without any lock has nothing to ask, so it passes.
    @MainActor static func unlock(reason: String) async -> Bool {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else { return true }
        return (try? await context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason)) ?? false
    }
}

/// The chats hidden with "Chat lock". Swipe a chat to take the lock off.
struct LockedChatsView: View {
    let onOpen: (ChatThread.ID) -> Void

    @Environment(AppState.self) private var state
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if state.chats.lockedThreads.isEmpty {
                    VStack(spacing: 8) {
                        Image(systemName: "lock")
                            .font(.system(size: 36))
                            .foregroundStyle(Theme.tabIconInactive)
                        Text("No locked chats")
                            .scaledFont(18, weight: .bold, maxScale: 1.2)
                            .foregroundStyle(Theme.ink)
                        Text("Turn on Chat lock in a chat's info to hide it here.")
                            .scaledFont(15, maxScale: 1.3)
                            .foregroundStyle(Theme.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(40)
                } else {
                    List {
                        ForEach(state.chats.lockedThreads) { thread in
                            Button { onOpen(thread.id) } label: {
                                HStack(spacing: 14) {
                                    ChatAvatar(thread: thread, size: 52)
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(thread.title)
                                            .scaledFont(17, weight: .semibold, maxScale: 1.25)
                                            .foregroundStyle(Theme.ink)
                                        Text(thread.preview)
                                            .scaledFont(15, maxScale: 1.25)
                                            .foregroundStyle(Theme.secondary)
                                            .lineLimit(1)
                                    }
                                }
                                .contentShape(.rect)
                            }
                            .buttonStyle(.plain)
                            .swipeActions {
                                Button { state.chats.toggleLock(thread.id) } label: {
                                    Label("Unlock", systemImage: "lock.open")
                                }
                                .tint(Theme.tabSelected)
                            }
                        }
                    }
                    .listStyle(.plain)
                    .scrollContentBackground(.hidden)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Theme.background)
            .navigationTitle("Locked chats")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
            }
        }
    }
}
