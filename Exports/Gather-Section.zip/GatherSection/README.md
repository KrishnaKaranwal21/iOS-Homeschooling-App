# HomeSchool — Gather section

Current source export from iOS-Homeschooling-App. All included source files are
unchanged copies of the working project.

## Contents

Source/Homeschool/Features/Gather/ includes the complete Gather feature folder:
- Gather feed, search, filters, interest categories and loading placeholders.
- Liked events, hosting, saved tickets and location picker/map views.
- Event details with fixed transparent header, organizer, description, FAQ dropdown,
  location, photos, calendar editor and report action.
- Registration, Going confirmation and booking tickets with event-specific QR codes,
  PNG downloads and native sharing.

Source/Homeschool/Core/ includes supporting event/registration/child/curriculum models,
the shared design system, native mascot and location service.

IntegrationReferences/ includes AppState, MainTabView, ProfileView, AuthServices and
MockData as context for connecting Gather to the host app. These reference files depend
on other app features/services that are not all included here.

SHA256SUMS.txt records the checksum of every included source/test/script file.

## Integration

This is a source bundle, not a standalone Xcode project or Swift package. Use the original
Homeschool Xcode project to build the full app. The existing Gather navigation setup is:

```swift
@Bindable var bindableState = state
NavigationStack(path: $bindableState.gatherPath) {
    GatherView()
}
.toolbarVisibility(state.hidesTabBar ? .hidden : .automatic, for: .tabBar)
```

The navigation stack inherits the shared AppState from the app's environment.
Use the shared AppAppearance/Theme setup for system, light and dark appearance.
When merging into the original project, update the feature files and reuse existing
shared definitions; do not add duplicate AppState, Event, Theme or other shared types.
For another app, adapt the profile, child/account, navigation and state hooks.

Frameworks used include SwiftUI, MapKit, CoreLocation, PhotosUI, EventKitUI, CoreImage,
CryptoKit and UniformTypeIdentifiers. Keep the original project's deployment target and
privacy configuration. LocationService requires a location-when-in-use usage description.
The calendar action presents Apple's native event editor for the user to confirm saving.

The default event poster artwork is drawn in SwiftUI. SF Symbols supply interface icons;
no separate Gather poster image assets are needed for the current implementation.
Host-picked photos are supplied by the app at runtime.

## Included checks

From Source/, on macOS with Xcode command-line tools available:

```sh
bash Scripts/check-gather.sh
bash Scripts/check-booking-tickets.sh
```

To scan a real exported ticket image as well:

```sh
bash Scripts/check-booking-tickets.sh /absolute/path/to/ticket.png
```

## Current implementation boundaries

- The event catalog is local/sample data, not a connected event service.
- Bookings and liked events are stored locally. QR codes identify the event and booking;
  automated admission validation needs an organizer check-in service.
- Event reports are saved on the device, not sent to a moderation service.
- Event photos and hosted-event catalog data currently use in-memory app state.

This archive excludes user data, credentials, signing settings, Git history, build outputs
and Xcode personal settings.
